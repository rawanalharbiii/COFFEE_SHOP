/* ensure all variables on this page match your project
 */

export const environment = {
  production: false,
  apiServerUrl: 'http://127.0.0.1:5000', // the running FLASK api server url
  auth0: {
    url: 'rawan-3.us', // the auth0 domain
    audience: 'Coffee_Shop', // the audience 
    clientId: 'SrNeJTuPfBJWU9uIZPmaw63w8mjhVih6', // the client id 
    callbackURL: 'http://localhost:8100',  
  }
};
